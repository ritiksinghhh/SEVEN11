ALTER TABLE public.studio_settings ADD COLUMN IF NOT EXISTS about_title TEXT;

COMMENT ON COLUMN public.studio_settings.about_title IS 'Editable title for the About page hero section';