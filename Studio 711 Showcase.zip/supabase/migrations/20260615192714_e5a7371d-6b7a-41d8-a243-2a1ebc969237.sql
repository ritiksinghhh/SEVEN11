
-- Restrict EXECUTE on SECURITY DEFINER helper to nobody (used only within RLS policy expressions, which bypass EXECUTE checks)
REVOKE EXECUTE ON FUNCTION public.has_role(uuid, public.app_role) FROM PUBLIC, anon, authenticated;

-- claim_admin_if_none: keep callable only by authenticated, never anon
REVOKE EXECUTE ON FUNCTION public.claim_admin_if_none() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.claim_admin_if_none() TO authenticated;

-- Harden user_roles: prevent admin policy from being abused to assign roles to oneself in a way that bypasses the first-admin claim flow.
-- Drop the broad ALL policy and split into specific commands with stricter checks.
DROP POLICY IF EXISTS "Admins can manage roles" ON public.user_roles;

CREATE POLICY "Admins can view all roles"
  ON public.user_roles FOR SELECT
  TO authenticated
  USING (public.has_role(auth.uid(), 'admin'::public.app_role));

CREATE POLICY "Admins can insert roles"
  ON public.user_roles FOR INSERT
  TO authenticated
  WITH CHECK (
    public.has_role(auth.uid(), 'admin'::public.app_role)
    AND user_id <> auth.uid()
  );

CREATE POLICY "Admins can update roles"
  ON public.user_roles FOR UPDATE
  TO authenticated
  USING (public.has_role(auth.uid(), 'admin'::public.app_role))
  WITH CHECK (
    public.has_role(auth.uid(), 'admin'::public.app_role)
    AND user_id <> auth.uid()
  );

CREATE POLICY "Admins can delete roles"
  ON public.user_roles FOR DELETE
  TO authenticated
  USING (
    public.has_role(auth.uid(), 'admin'::public.app_role)
    AND user_id <> auth.uid()
  );

-- Storage: remove broad public listing on project-images. Files remain accessible via public bucket URLs
-- (/storage/v1/object/public/...), but bucket contents cannot be enumerated via the API.
DROP POLICY IF EXISTS "Public can view project images" ON storage.objects;
