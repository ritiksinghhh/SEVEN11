REVOKE EXECUTE ON FUNCTION public.claim_admin_if_none() FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.claim_admin_if_none() TO service_role;