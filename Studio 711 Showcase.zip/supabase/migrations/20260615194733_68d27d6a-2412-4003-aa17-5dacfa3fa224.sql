CREATE SCHEMA IF NOT EXISTS app_private;

CREATE OR REPLACE FUNCTION app_private.has_role(_user_id uuid, _role public.app_role)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.user_roles
    WHERE user_id = _user_id
      AND role = _role
  )
$$;

REVOKE ALL ON SCHEMA app_private FROM PUBLIC;
GRANT USAGE ON SCHEMA app_private TO authenticated, service_role;
REVOKE EXECUTE ON FUNCTION app_private.has_role(uuid, public.app_role) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION app_private.has_role(uuid, public.app_role) TO authenticated, service_role;

-- Keep the public helper unavailable as an API/RPC target.
REVOKE EXECUTE ON FUNCTION public.has_role(uuid, public.app_role) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.has_role(uuid, public.app_role) TO service_role;

-- user_roles policies
DROP POLICY IF EXISTS "Admins can view all roles" ON public.user_roles;
DROP POLICY IF EXISTS "Admins can insert roles" ON public.user_roles;
DROP POLICY IF EXISTS "Admins can update roles" ON public.user_roles;
DROP POLICY IF EXISTS "Admins can delete roles" ON public.user_roles;

CREATE POLICY "Admins can view all roles"
  ON public.user_roles FOR SELECT
  TO authenticated
  USING (app_private.has_role(auth.uid(), 'admin'::public.app_role));

CREATE POLICY "Admins can insert roles"
  ON public.user_roles FOR INSERT
  TO authenticated
  WITH CHECK (
    app_private.has_role(auth.uid(), 'admin'::public.app_role)
    AND user_id <> auth.uid()
  );

CREATE POLICY "Admins can update roles"
  ON public.user_roles FOR UPDATE
  TO authenticated
  USING (app_private.has_role(auth.uid(), 'admin'::public.app_role))
  WITH CHECK (
    app_private.has_role(auth.uid(), 'admin'::public.app_role)
    AND user_id <> auth.uid()
  );

CREATE POLICY "Admins can delete roles"
  ON public.user_roles FOR DELETE
  TO authenticated
  USING (
    app_private.has_role(auth.uid(), 'admin'::public.app_role)
    AND user_id <> auth.uid()
  );

-- Admin-only content policies
DROP POLICY IF EXISTS "Admins can insert projects" ON public.projects;
DROP POLICY IF EXISTS "Admins can update projects" ON public.projects;
DROP POLICY IF EXISTS "Admins can delete projects" ON public.projects;
DROP POLICY IF EXISTS "Admins can insert services" ON public.services;
DROP POLICY IF EXISTS "Admins can update services" ON public.services;
DROP POLICY IF EXISTS "Admins can delete services" ON public.services;
DROP POLICY IF EXISTS "Admins can insert studio settings" ON public.studio_settings;
DROP POLICY IF EXISTS "Admins can update studio settings" ON public.studio_settings;
DROP POLICY IF EXISTS "Admins can delete studio settings" ON public.studio_settings;
DROP POLICY IF EXISTS "Admins can insert team members" ON public.team_members;
DROP POLICY IF EXISTS "Admins can update team members" ON public.team_members;
DROP POLICY IF EXISTS "Admins can delete team members" ON public.team_members;

CREATE POLICY "Admins can insert projects" ON public.projects
  FOR INSERT TO authenticated WITH CHECK (app_private.has_role(auth.uid(), 'admin'::public.app_role));
CREATE POLICY "Admins can update projects" ON public.projects
  FOR UPDATE TO authenticated USING (app_private.has_role(auth.uid(), 'admin'::public.app_role));
CREATE POLICY "Admins can delete projects" ON public.projects
  FOR DELETE TO authenticated USING (app_private.has_role(auth.uid(), 'admin'::public.app_role));

CREATE POLICY "Admins can insert services" ON public.services
  FOR INSERT TO authenticated WITH CHECK (app_private.has_role(auth.uid(), 'admin'::public.app_role));
CREATE POLICY "Admins can update services" ON public.services
  FOR UPDATE TO authenticated USING (app_private.has_role(auth.uid(), 'admin'::public.app_role));
CREATE POLICY "Admins can delete services" ON public.services
  FOR DELETE TO authenticated USING (app_private.has_role(auth.uid(), 'admin'::public.app_role));

CREATE POLICY "Admins can insert studio settings" ON public.studio_settings
  FOR INSERT TO authenticated WITH CHECK (app_private.has_role(auth.uid(), 'admin'::public.app_role));
CREATE POLICY "Admins can update studio settings" ON public.studio_settings
  FOR UPDATE TO authenticated USING (app_private.has_role(auth.uid(), 'admin'::public.app_role));
CREATE POLICY "Admins can delete studio settings" ON public.studio_settings
  FOR DELETE TO authenticated USING (app_private.has_role(auth.uid(), 'admin'::public.app_role));

CREATE POLICY "Admins can insert team members" ON public.team_members
  FOR INSERT TO authenticated WITH CHECK (app_private.has_role(auth.uid(), 'admin'::public.app_role));
CREATE POLICY "Admins can update team members" ON public.team_members
  FOR UPDATE TO authenticated USING (app_private.has_role(auth.uid(), 'admin'::public.app_role));
CREATE POLICY "Admins can delete team members" ON public.team_members
  FOR DELETE TO authenticated USING (app_private.has_role(auth.uid(), 'admin'::public.app_role));

DROP POLICY IF EXISTS "Admins can upload project images" ON storage.objects;
DROP POLICY IF EXISTS "Admins can update project images" ON storage.objects;
DROP POLICY IF EXISTS "Admins can delete project images" ON storage.objects;

CREATE POLICY "Admins can upload project images"
  ON storage.objects FOR INSERT TO authenticated
  WITH CHECK (bucket_id = 'project-images' AND app_private.has_role(auth.uid(), 'admin'::public.app_role));
CREATE POLICY "Admins can update project images"
  ON storage.objects FOR UPDATE TO authenticated
  USING (bucket_id = 'project-images' AND app_private.has_role(auth.uid(), 'admin'::public.app_role));
CREATE POLICY "Admins can delete project images"
  ON storage.objects FOR DELETE TO authenticated
  USING (bucket_id = 'project-images' AND app_private.has_role(auth.uid(), 'admin'::public.app_role));